from django.apps import AppConfig


class FacultyDashboardConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'faculty_dashboard'
